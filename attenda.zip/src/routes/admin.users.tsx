import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RoleGuard } from "@/components/RoleGuard";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/users")({
  head: () => ({ meta: [{ title: "Users — Attenda admin" }] }),
  component: () => <RoleGuard allow={["admin"]}><UsersAdmin /></RoleGuard>,
});

interface UserRow {
  id: string;
  full_name: string;
  roll_number: string | null;
  class_id: string | null;
  role: "admin" | "teacher" | "student";
}

interface ClassRow { id: string; name: string; section: string | null; }

function UsersAdmin() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [filter, setFilter] = useState<"all" | "admin" | "teacher" | "student">("all");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data: profs } = await supabase.from("profiles").select("id, full_name, roll_number, class_id");
    const { data: roles } = await supabase.from("user_roles").select("user_id, role");
    const { data: cls } = await supabase.from("classes").select("id, name, section").order("name");
    const roleMap = new Map<string, UserRow["role"]>();
    roles?.forEach((r) => roleMap.set(r.user_id, r.role as UserRow["role"]));
    setUsers((profs ?? []).map((p) => ({ ...p, role: roleMap.get(p.id) ?? "student" })));
    setClasses(cls ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const updateUser = async (id: string, patch: Partial<UserRow>) => {
    const { role: newRole, ...profilePatch } = patch;
    if (Object.keys(profilePatch).length) {
      const { error } = await supabase.from("profiles").update(profilePatch).eq("id", id);
      if (error) return toast.error(error.message);
    }
    if (newRole) {
      await supabase.from("user_roles").delete().eq("user_id", id);
      const { error } = await supabase.from("user_roles").insert({ user_id: id, role: newRole });
      if (error) return toast.error(error.message);
    }
    toast.success("User updated");
    load();
  };

  const deleteUser = async (id: string) => {
    if (!confirm("Delete this user's profile? (Auth account remains)")) return;
    const { error } = await supabase.from("profiles").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Deleted"); load(); }
  };

  const filtered = filter === "all" ? users : users.filter((u) => u.role === filter);

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold">Users</h1>
          <p className="text-muted-foreground mt-1">Manage students, teachers, and admins.</p>
        </div>
        <div className="w-full sm:w-48">
          <Label className="text-xs text-muted-foreground">Filter by role</Label>
          <Select value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="admin">Admins</SelectItem>
              <SelectItem value="teacher">Teachers</SelectItem>
              <SelectItem value="student">Students</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <p className="text-xs text-muted-foreground mt-4">
        New users sign up via the public signup page (or invite link). Here you can edit their role, class, roll number, and remove their profile.
      </p>

      <div className="mt-4 rounded-2xl border bg-card overflow-x-auto shadow-soft">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Roll #</TableHead>
              <TableHead>Class</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading && (<TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>)}
            {!loading && filtered.length === 0 && (<TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No users yet.</TableCell></TableRow>)}
            {filtered.map((u) => (
              <TableRow key={u.id}>
                <TableCell>
                  <Input defaultValue={u.full_name} onBlur={(e) => e.target.value !== u.full_name && updateUser(u.id, { full_name: e.target.value })} className="h-8" />
                </TableCell>
                <TableCell>
                  <Select value={u.role} onValueChange={(v) => updateUser(u.id, { role: v as UserRow["role"] })}>
                    <SelectTrigger className="h-8 w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="teacher">Teacher</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  <Input defaultValue={u.roll_number ?? ""} onBlur={(e) => updateUser(u.id, { roll_number: e.target.value || null })} className="h-8 w-28" />
                </TableCell>
                <TableCell>
                  <Select value={u.class_id ?? "none"} onValueChange={(v) => updateUser(u.id, { class_id: v === "none" ? null : v })}>
                    <SelectTrigger className="h-8 w-40"><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">— None —</SelectItem>
                      {classes.map((c) => (
                        <SelectItem key={c.id} value={c.id}>{c.name}{c.section ? ` (${c.section})` : ""}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell className="text-right">
                  <Button size="sm" variant="ghost" onClick={() => deleteUser(u.id)}>Delete</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="mt-3 text-xs text-muted-foreground flex items-center gap-2">
        <Badge variant="outline">Tip</Badge> Edits save when you leave the field.
      </div>
    </div>
  );
}
