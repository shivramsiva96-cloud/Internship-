import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { RoleGuard } from "@/components/RoleGuard";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/")({
  head: () => ({ meta: [{ title: "Mark Attendance — Attenda" }] }),
  component: () => <RoleGuard allow={["teacher", "admin"]}><MarkAttendance /></RoleGuard>,
});

type Status = "present" | "absent" | "late";
interface Student { id: string; full_name: string; roll_number: string | null; }

function MarkAttendance() {
  const { user } = useAuth();
  const [classes, setClasses] = useState<{ id: string; name: string; section: string | null }[]>([]);
  const [subjects, setSubjects] = useState<{ id: string; name: string; class_id: string | null }[]>([]);
  const [classId, setClassId] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [students, setStudents] = useState<Student[]>([]);
  const [marks, setMarks] = useState<Record<string, Status>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const [{ data: c }, { data: s }] = await Promise.all([
        supabase.from("classes").select("*").order("name"),
        supabase.from("subjects").select("*").order("name"),
      ]);
      setClasses(c ?? []);
      setSubjects(s ?? []);
    })();
  }, []);

  const subjectOptions = useMemo(() => subjects.filter((s) => s.class_id === classId), [subjects, classId]);

  useEffect(() => { setSubjectId(""); }, [classId]);

  useEffect(() => {
    if (!classId) { setStudents([]); return; }
    (async () => {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, full_name, roll_number")
        .eq("class_id", classId);
      const ids = (profs ?? []).map((p) => p.id);
      if (ids.length === 0) { setStudents([]); return; }
      const { data: roles } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("user_id", ids)
        .eq("role", "student");
      const studentIds = new Set((roles ?? []).map((r) => r.user_id));
      const list = (profs ?? []).filter((p) => studentIds.has(p.id));
      setStudents(list);
      const init: Record<string, Status> = {};
      list.forEach((s) => (init[s.id] = "present"));
      setMarks(init);
    })();
  }, [classId]);

  // Load existing attendance for the chosen date/subject
  useEffect(() => {
    if (!classId || !subjectId || !date || students.length === 0) return;
    (async () => {
      const { data } = await supabase
        .from("attendance")
        .select("student_id, status")
        .eq("class_id", classId)
        .eq("subject_id", subjectId)
        .eq("date", date);
      if (data && data.length) {
        setMarks((prev) => {
          const next = { ...prev };
          data.forEach((r) => { next[r.student_id] = r.status as Status; });
          return next;
        });
      }
    })();
  }, [classId, subjectId, date, students]);

  const submit = async () => {
    if (!classId || !subjectId || !date) return toast.error("Pick class, subject, and date");
    if (students.length === 0) return toast.error("No students in this class");
    setSaving(true);
    const rows = students.map((s) => ({
      student_id: s.id,
      class_id: classId,
      subject_id: subjectId,
      date,
      status: marks[s.id] ?? "present",
      marked_by: user?.id,
    }));
    const { error } = await supabase.from("attendance").upsert(rows, { onConflict: "student_id,subject_id,date" });
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success(`Saved attendance for ${rows.length} student${rows.length === 1 ? "" : "s"}`);
  };

  const setAll = (s: Status) => {
    const next: Record<string, Status> = {};
    students.forEach((st) => (next[st.id] = s));
    setMarks(next);
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Mark Attendance</h1>
      <p className="text-muted-foreground mt-1">Select a class, subject, and date — then mark each student.</p>

      <div className="mt-6 rounded-2xl border bg-card p-5 shadow-soft grid gap-4 sm:grid-cols-3">
        <div className="space-y-1.5">
          <Label>Class</Label>
          <Select value={classId} onValueChange={setClassId}>
            <SelectTrigger><SelectValue placeholder="Pick class" /></SelectTrigger>
            <SelectContent>
              {classes.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}{c.section ? ` · ${c.section}` : ""}</SelectItem>))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Subject</Label>
          <Select value={subjectId} onValueChange={setSubjectId} disabled={!classId}>
            <SelectTrigger><SelectValue placeholder={classId ? "Pick subject" : "Pick class first"} /></SelectTrigger>
            <SelectContent>
              {subjectOptions.map((s) => (<SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Date</Label>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </div>
      </div>

      {classId && subjectId && (
        <div className="mt-6 rounded-2xl border bg-card shadow-soft overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b gap-2 flex-wrap">
            <p className="font-semibold">{students.length} student{students.length === 1 ? "" : "s"}</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => setAll("present")}>All present</Button>
              <Button size="sm" variant="outline" onClick={() => setAll("absent")}>All absent</Button>
              <Button size="sm" onClick={submit} disabled={saving}>{saving ? "Saving…" : "Save attendance"}</Button>
            </div>
          </div>
          <ul className="divide-y">
            {students.length === 0 && <li className="p-6 text-sm text-muted-foreground text-center">No students enrolled in this class.</li>}
            {students.map((s) => {
              const st = marks[s.id] ?? "present";
              return (
                <li key={s.id} className="flex items-center justify-between p-4 gap-4">
                  <div>
                    <p className="font-medium">{s.full_name}</p>
                    {s.roll_number && <p className="text-xs text-muted-foreground">Roll #{s.roll_number}</p>}
                  </div>
                  <div className="flex gap-1">
                    {(["present", "late", "absent"] as Status[]).map((opt) => (
                      <button
                        key={opt}
                        onClick={() => setMarks((m) => ({ ...m, [s.id]: opt }))}
                        className={`text-xs font-medium rounded-md px-3 py-1.5 capitalize transition-colors ${
                          st === opt
                            ? opt === "present" ? "bg-success text-success-foreground"
                              : opt === "late" ? "bg-warning text-warning-foreground"
                              : "bg-destructive text-destructive-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/70"
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
