import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { RoleGuard } from "@/components/RoleGuard";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CheckCircle2, XCircle, Clock } from "lucide-react";

export const Route = createFileRoute("/student/")({
  head: () => ({ meta: [{ title: "My Attendance — Attenda" }] }),
  component: () => <RoleGuard allow={["student"]}><StudentDashboard /></RoleGuard>,
});

type Range = "daily" | "weekly" | "monthly" | "all";

function StudentDashboard() {
  const { user } = useAuth();
  const [range, setRange] = useState<Range>("monthly");
  const [records, setRecords] = useState<{ id: string; date: string; status: "present" | "absent" | "late"; subject: string; class_name: string }[]>([]);

  const since = useMemo(() => {
    const d = new Date();
    if (range === "daily") d.setDate(d.getDate() - 1);
    else if (range === "weekly") d.setDate(d.getDate() - 7);
    else if (range === "monthly") d.setMonth(d.getMonth() - 1);
    else return null;
    return d.toISOString().slice(0, 10);
  }, [range]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      let q = supabase
        .from("attendance")
        .select("id, date, status, subjects(name), classes(name, section)")
        .eq("student_id", user.id)
        .order("date", { ascending: false });
      if (since) q = q.gte("date", since);
      const { data } = await q;
      setRecords(
        (data ?? []).map((r: any) => ({
          id: r.id, date: r.date, status: r.status,
          subject: r.subjects?.name ?? "—",
          class_name: r.classes ? `${r.classes.name}${r.classes.section ? ` · ${r.classes.section}` : ""}` : "—",
        }))
      );
    })();
  }, [user, since]);

  const totals = records.reduce(
    (acc, r) => { acc.total++; acc[r.status]++; return acc; },
    { total: 0, present: 0, absent: 0, late: 0 }
  );
  const pct = totals.total ? ((totals.present + totals.late) / totals.total) * 100 : 0;

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">My Attendance</h1>
      <p className="text-muted-foreground mt-1">Your attendance history and summary.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border bg-card p-5 shadow-soft">
          <p className="text-sm text-muted-foreground">Attendance %</p>
          <p className={`mt-1 font-display text-3xl font-bold ${pct >= 75 ? "text-success" : pct >= 50 ? "text-warning" : "text-destructive"}`}>
            {pct.toFixed(1)}%
          </p>
        </div>
        <Stat icon={CheckCircle2} color="text-success" label="Present" value={totals.present} />
        <Stat icon={Clock} color="text-warning" label="Late" value={totals.late} />
        <Stat icon={XCircle} color="text-destructive" label="Absent" value={totals.absent} />
      </div>

      <div className="mt-6 flex items-end justify-between gap-4 flex-wrap">
        <h2 className="font-display text-lg font-semibold">Records</h2>
        <div className="w-48">
          <Label className="text-xs text-muted-foreground">Range</Label>
          <Select value={range} onValueChange={(v) => setRange(v as Range)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Last 24 hours</SelectItem>
              <SelectItem value="weekly">Last 7 days</SelectItem>
              <SelectItem value="monthly">Last 30 days</SelectItem>
              <SelectItem value="all">All time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="mt-3 rounded-2xl border bg-card overflow-x-auto shadow-soft">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>Subject</TableHead>
              <TableHead className="text-right">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {records.length === 0 && (<TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No attendance records yet.</TableCell></TableRow>)}
            {records.map((r) => (
              <TableRow key={r.id}>
                <TableCell>{r.date}</TableCell>
                <TableCell>{r.class_name}</TableCell>
                <TableCell>{r.subject}</TableCell>
                <TableCell className="text-right">
                  <span className={`text-xs font-semibold rounded-full px-2.5 py-1 capitalize ${
                    r.status === "present" ? "bg-success/15 text-success"
                    : r.status === "late" ? "bg-warning/20 text-warning-foreground"
                    : "bg-destructive/15 text-destructive"
                  }`}>{r.status}</span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, color, label, value }: { icon: typeof CheckCircle2; color: string; label: string; value: number }) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-soft">
      <Icon className={`h-5 w-5 ${color}`} />
      <p className="mt-3 text-sm text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-3xl font-bold">{value}</p>
    </div>
  );
}
