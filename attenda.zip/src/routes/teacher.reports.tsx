import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { RoleGuard } from "@/components/RoleGuard";
import { supabase } from "@/integrations/supabase/client";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export const Route = createFileRoute("/teacher/reports")({
  head: () => ({ meta: [{ title: "Reports — Attenda" }] }),
  component: () => <RoleGuard allow={["teacher", "admin"]}><Reports /></RoleGuard>,
});

type Range = "daily" | "weekly" | "monthly";

function Reports() {
  const [classes, setClasses] = useState<{ id: string; name: string; section: string | null }[]>([]);
  const [classId, setClassId] = useState("");
  const [range, setRange] = useState<Range>("weekly");
  const [rows, setRows] = useState<{ id: string; name: string; roll: string | null; present: number; late: number; absent: number; total: number }[]>([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("classes").select("*").order("name");
      setClasses(data ?? []);
    })();
  }, []);

  const since = useMemo(() => {
    const d = new Date();
    if (range === "daily") d.setDate(d.getDate() - 1);
    else if (range === "weekly") d.setDate(d.getDate() - 7);
    else d.setMonth(d.getMonth() - 1);
    return d.toISOString().slice(0, 10);
  }, [range]);

  useEffect(() => {
    if (!classId) { setRows([]); return; }
    (async () => {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, full_name, roll_number")
        .eq("class_id", classId);
      const ids = (profs ?? []).map((p) => p.id);
      if (ids.length === 0) { setRows([]); return; }
      const { data: roles } = await supabase
        .from("user_roles").select("user_id, role").in("user_id", ids).eq("role", "student");
      const studentIds = new Set((roles ?? []).map((r) => r.user_id));
      const studs = (profs ?? []).filter((p) => studentIds.has(p.id));

      const { data: att } = await supabase
        .from("attendance")
        .select("student_id, status, date")
        .eq("class_id", classId)
        .gte("date", since);

      const map = new Map<string, { present: number; late: number; absent: number; total: number }>();
      studs.forEach((s) => map.set(s.id, { present: 0, late: 0, absent: 0, total: 0 }));
      (att ?? []).forEach((a) => {
        const m = map.get(a.student_id);
        if (!m) return;
        m.total++;
        if (a.status === "present") m.present++;
        else if (a.status === "late") m.late++;
        else m.absent++;
      });
      setRows(studs.map((s) => ({ id: s.id, name: s.full_name, roll: s.roll_number, ...(map.get(s.id)!) })));
    })();
  }, [classId, since]);

  const exportCsv = () => {
    const header = ["Name", "Roll", "Present", "Late", "Absent", "Total", "Percentage"];
    const lines = rows.map((r) => {
      const pct = r.total ? (((r.present + r.late) / r.total) * 100).toFixed(1) : "0";
      return [r.name, r.roll ?? "", r.present, r.late, r.absent, r.total, pct + "%"].join(",");
    });
    const blob = new Blob([header.join(",") + "\n" + lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `attendance-${range}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Reports</h1>
      <p className="text-muted-foreground mt-1">Attendance summary by class and time range.</p>

      <div className="mt-6 rounded-2xl border bg-card p-5 shadow-soft grid gap-4 sm:grid-cols-[1fr_1fr_auto] items-end">
        <div className="space-y-1.5">
          <Label>Class</Label>
          <Select value={classId} onValueChange={setClassId}>
            <SelectTrigger><SelectValue placeholder="Pick class" /></SelectTrigger>
            <SelectContent>
              {classes.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}{c.section ? ` · ${c.section}` : ""}</SelectItem>))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Range</Label>
          <Select value={range} onValueChange={(v) => setRange(v as Range)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Last 24 hours</SelectItem>
              <SelectItem value="weekly">Last 7 days</SelectItem>
              <SelectItem value="monthly">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button variant="outline" onClick={exportCsv} disabled={rows.length === 0}>
          <Download className="h-4 w-4 mr-2" /> Export CSV
        </Button>
      </div>

      <div className="mt-6 rounded-2xl border bg-card overflow-x-auto shadow-soft">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Student</TableHead>
              <TableHead>Roll</TableHead>
              <TableHead className="text-right">Present</TableHead>
              <TableHead className="text-right">Late</TableHead>
              <TableHead className="text-right">Absent</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead className="text-right">%</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 && (<TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">{classId ? "No data for this range." : "Pick a class to begin."}</TableCell></TableRow>)}
            {rows.map((r) => {
              const pct = r.total ? ((r.present + r.late) / r.total) * 100 : 0;
              return (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{r.name}</TableCell>
                  <TableCell className="text-muted-foreground">{r.roll ?? "—"}</TableCell>
                  <TableCell className="text-right">{r.present}</TableCell>
                  <TableCell className="text-right">{r.late}</TableCell>
                  <TableCell className="text-right">{r.absent}</TableCell>
                  <TableCell className="text-right">{r.total}</TableCell>
                  <TableCell className="text-right">
                    <span className={`font-semibold ${pct >= 75 ? "text-success" : pct >= 50 ? "text-warning" : "text-destructive"}`}>
                      {pct.toFixed(1)}%
                    </span>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
