import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RoleGuard } from "@/components/RoleGuard";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";

export const Route = createFileRoute("/admin/classes")({
  head: () => ({ meta: [{ title: "Classes & Subjects — Attenda admin" }] }),
  component: () => <RoleGuard allow={["admin"]}><ClassesAdmin /></RoleGuard>,
});

interface ClassRow { id: string; name: string; section: string | null; }
interface SubjectRow { id: string; name: string; class_id: string | null; }

function ClassesAdmin() {
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [subjects, setSubjects] = useState<SubjectRow[]>([]);
  const [className, setClassName] = useState("");
  const [section, setSection] = useState("");
  const [subjectName, setSubjectName] = useState("");
  const [subjectClass, setSubjectClass] = useState<string>("");

  const load = async () => {
    const [{ data: c }, { data: s }] = await Promise.all([
      supabase.from("classes").select("*").order("name"),
      supabase.from("subjects").select("*").order("name"),
    ]);
    setClasses(c ?? []);
    setSubjects(s ?? []);
  };
  useEffect(() => { load(); }, []);

  const addClass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!className.trim()) return;
    const { error } = await supabase.from("classes").insert({ name: className.trim(), section: section.trim() || null });
    if (error) toast.error(error.message);
    else { toast.success("Class added"); setClassName(""); setSection(""); load(); }
  };

  const addSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectName.trim() || !subjectClass) return;
    const { error } = await supabase.from("subjects").insert({ name: subjectName.trim(), class_id: subjectClass });
    if (error) toast.error(error.message);
    else { toast.success("Subject added"); setSubjectName(""); load(); }
  };

  const delClass = async (id: string) => {
    if (!confirm("Delete this class? Subjects and attendance will be removed.")) return;
    const { error } = await supabase.from("classes").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); load(); }
  };
  const delSubject = async (id: string) => {
    const { error } = await supabase.from("subjects").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); load(); }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Classes & Subjects</h1>
      <p className="text-muted-foreground mt-1">Set up the academic structure.</p>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border bg-card p-5 shadow-soft">
          <h2 className="font-display text-lg font-semibold">Classes</h2>
          <form onSubmit={addClass} className="mt-4 grid grid-cols-[1fr_auto_auto] gap-2">
            <Input placeholder="Class name (e.g. Grade 10)" value={className} onChange={(e) => setClassName(e.target.value)} />
            <Input placeholder="Section" value={section} onChange={(e) => setSection(e.target.value)} className="w-24" />
            <Button type="submit">Add</Button>
          </form>
          <ul className="mt-4 divide-y">
            {classes.length === 0 && <li className="py-3 text-sm text-muted-foreground">No classes yet.</li>}
            {classes.map((c) => (
              <li key={c.id} className="flex items-center justify-between py-2.5">
                <span className="text-sm font-medium">{c.name}{c.section ? ` · ${c.section}` : ""}</span>
                <Button size="icon" variant="ghost" onClick={() => delClass(c.id)}><Trash2 className="h-4 w-4" /></Button>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-2xl border bg-card p-5 shadow-soft">
          <h2 className="font-display text-lg font-semibold">Subjects</h2>
          <form onSubmit={addSubject} className="mt-4 grid gap-2">
            <Input placeholder="Subject name (e.g. Mathematics)" value={subjectName} onChange={(e) => setSubjectName(e.target.value)} />
            <div className="grid grid-cols-[1fr_auto] gap-2">
              <div>
                <Label className="text-xs text-muted-foreground">Class</Label>
                <Select value={subjectClass} onValueChange={setSubjectClass}>
                  <SelectTrigger><SelectValue placeholder="Pick a class" /></SelectTrigger>
                  <SelectContent>
                    {classes.map((c) => (<SelectItem key={c.id} value={c.id}>{c.name}{c.section ? ` · ${c.section}` : ""}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="self-end">Add</Button>
            </div>
          </form>
          <ul className="mt-4 divide-y">
            {subjects.length === 0 && <li className="py-3 text-sm text-muted-foreground">No subjects yet.</li>}
            {subjects.map((s) => {
              const cls = classes.find((c) => c.id === s.class_id);
              return (
                <li key={s.id} className="flex items-center justify-between py-2.5">
                  <span className="text-sm font-medium">
                    {s.name}
                    <span className="ml-2 text-xs text-muted-foreground">{cls ? cls.name + (cls.section ? ` · ${cls.section}` : "") : "—"}</span>
                  </span>
                  <Button size="icon" variant="ghost" onClick={() => delSubject(s.id)}><Trash2 className="h-4 w-4" /></Button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
}
