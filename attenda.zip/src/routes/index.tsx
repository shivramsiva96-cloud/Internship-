import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { GraduationCap, ClipboardCheck, BarChart3, Users, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Attenda — Smart attendance for modern classrooms" },
      { name: "description", content: "A clean, secure attendance management system for admins, teachers, and students." },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { user, role, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user && role) {
      const home = role === "admin" ? "/admin" : role === "teacher" ? "/teacher" : "/student";
      navigate({ to: home });
    }
  }, [user, role, loading, navigate]);

  return (
    <div className="min-h-screen bg-background">
      <header className="container mx-auto flex items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-brand">
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="font-display text-lg font-bold">Attenda</span>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" asChild><Link to="/login">Sign in</Link></Button>
          <Button asChild><Link to="/signup">Get started</Link></Button>
        </div>
      </header>

      <section className="container mx-auto px-6 pt-12 pb-20 md:pt-24 md:pb-32 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs font-medium text-muted-foreground shadow-soft">
          <ShieldCheck className="h-3.5 w-3.5 text-primary" /> Secure role-based access
        </div>
        <h1 className="mt-6 font-display text-4xl md:text-6xl font-extrabold tracking-tight">
          Attendance, <span className="text-gradient-brand">simplified</span>.
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-base md:text-lg text-muted-foreground">
          One workspace for administrators, teachers, and students to mark, track, and analyze classroom attendance — beautifully.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Button size="lg" asChild><Link to="/signup">Create free account</Link></Button>
          <Button size="lg" variant="outline" asChild><Link to="/login">Sign in</Link></Button>
        </div>
      </section>

      <section className="container mx-auto px-6 pb-24 grid gap-5 md:grid-cols-3">
        {[
          { icon: Users, title: "Admin control", body: "Manage teachers, students, classes, and subjects from one place." },
          { icon: ClipboardCheck, title: "One-tap marking", body: "Teachers mark a whole class in seconds — date and subject aware." },
          { icon: BarChart3, title: "Insightful reports", body: "Daily, weekly, and monthly summaries with attendance percentages." },
        ].map((f) => (
          <div key={f.title} className="rounded-2xl border bg-card p-6 shadow-soft">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent text-accent-foreground">
              <f.icon className="h-5 w-5" />
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold">{f.title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{f.body}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
