import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RoleGuard } from "@/components/RoleGuard";
import { supabase } from "@/integrations/supabase/client";
import { Users, BookOpen, ClipboardCheck, GraduationCap } from "lucide-react";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "Admin overview — Attenda" }] }),
  component: () => <RoleGuard allow={["admin"]}><AdminOverview /></RoleGuard>,
});

function AdminOverview() {
  const [stats, setStats] = useState({ students: 0, teachers: 0, classes: 0, attendance: 0 });

  useEffect(() => {
    (async () => {
      const [s, t, c, a] = await Promise.all([
        supabase.from("user_roles").select("user_id", { count: "exact", head: true }).eq("role", "student"),
        supabase.from("user_roles").select("user_id", { count: "exact", head: true }).eq("role", "teacher"),
        supabase.from("classes").select("id", { count: "exact", head: true }),
        supabase.from("attendance").select("id", { count: "exact", head: true }),
      ]);
      setStats({ students: s.count ?? 0, teachers: t.count ?? 0, classes: c.count ?? 0, attendance: a.count ?? 0 });
    })();
  }, []);

  const cards = [
    { label: "Students", value: stats.students, icon: GraduationCap, color: "from-primary to-primary-glow" },
    { label: "Teachers", value: stats.teachers, icon: Users, color: "from-success to-primary-glow" },
    { label: "Classes", value: stats.classes, icon: BookOpen, color: "from-warning to-primary" },
    { label: "Attendance records", value: stats.attendance, icon: ClipboardCheck, color: "from-primary-glow to-primary" },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Overview</h1>
      <p className="text-muted-foreground mt-1">A quick snapshot of your institution.</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border bg-card p-5 shadow-soft">
            <div className={`inline-flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br ${c.color} text-primary-foreground`}>
              <c.icon className="h-5 w-5" />
            </div>
            <p className="mt-4 text-sm text-muted-foreground">{c.label}</p>
            <p className="mt-1 font-display text-3xl font-bold">{c.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
