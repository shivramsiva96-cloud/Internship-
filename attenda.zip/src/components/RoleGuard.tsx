import { useEffect, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useAuth, type AppRole } from "@/lib/auth-context";
import { AppShell } from "@/components/AppShell";

export function RoleGuard({ allow, children }: { allow: AppRole[]; children: ReactNode }) {
  const { user, role, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) return;
    if (!user) navigate({ to: "/login" });
    else if (role && !allow.includes(role)) {
      const home = role === "admin" ? "/admin" : role === "teacher" ? "/teacher" : "/student";
      navigate({ to: home });
    }
  }, [user, role, loading, allow, navigate]);

  if (loading || !user || !role) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }
  if (!allow.includes(role)) return null;
  return <AppShell>{children}</AppShell>;
}
